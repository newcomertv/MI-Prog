#include <stdio.h>

int main () {
  printf("Mon premier programme en C affiche cette phrase.\n");
  return 0;
}
