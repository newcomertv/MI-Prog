#include <stdio.h>

int main () {
  int i = 17;
  printf("Mon troisi�me programme en C affiche un entier : %d\n",i);
  return 0;
}
