#include <stdio.h>

int main () {
  int i;
  scanf("%i",&i); 
  printf("%i\n",3*i);
  return 0;
}
