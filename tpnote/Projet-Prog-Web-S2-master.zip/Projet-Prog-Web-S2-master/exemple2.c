#include <stdio.h>

int main () {
  printf("Mon deuxi�me programme en C oublie de revenir � la ligne.");
  return 0;
}
